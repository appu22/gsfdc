<?php
error_reporting(0);
session_start();
unset($_SESSION['uname']);
session_destroy();
?>
<script type="text/javascript">
alert("Logged Out");
document.location="login.php";
</script>