<?php session_start(); ?>
<?php
	error_reporting(0);
	$username=$_POST["username"];
	$password=$_POST["password"];	
	
	include('dbconnect.php');
	$sql="select * from login where username='$username' and password='$password'";
	$res=mysql_query($sql);
	
	if($row=mysql_fetch_array($res))
	{
	$type=$row["type"];
$_SESSION["username"]=$username;

	if($type=="admin")
	{

	?>
	<script>
	document.location="admin/index.php";
	</script>
	<?php
	}
	else if($type=="customer")
	{

	?>
	<script>
	document.location="customer/index.php";
	</script>
	
	<?php
	}
}
else
	{
	?>
	<script>
	alert("Invalid User name Or Password");
	history.back();
	</script>
	<?php
	}
	?>