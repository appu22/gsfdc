<?php 
//$cn=mysqli_connect("localhost","root","appu22","gsfdc");
$n_title=$_POST['n_title'];
$n_date=$_POST['n_date'];
$descr=$_POST['descr'];

include('dbconnect.php');
$sql="insert into news values(null,'$n_title','$n_date','$descr')";
mysql_query($sql);
 // $res=mysql_query($sql);

?>
<script>
alert('values inserted' )
document.location="news_view.php";
//document.location="stud.php";
</script>