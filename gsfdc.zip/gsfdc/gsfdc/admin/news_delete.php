<?php

$id=$_REQUEST['id'];
include('dbconnect.php');

$sql="delete from news where news_id='$id'";
$res=mysql_query($sql);

?>
<script>
alert('Values deleted');
document.location="news_view.php";
</script>