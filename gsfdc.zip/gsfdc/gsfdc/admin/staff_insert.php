<?php
$staff_name=$_POST['staff_name'];
$quali=$_POST['quali'];
$designation=$_POST['designation'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$j_date=$_POST['j_date']; 
$photo=$_POST['photo'];

//$cn=mysqli_connect("localhost","root","appu22","gsfdc");
include('dbconnect.php');
$sql="insert into staff values(null,'$staff_name','$quali','$designation','$contact','$email','$j_date','$photo')";

mysql_query($sql);
?>
<script>
alert('values inserted')
document.location="staff_view.php";
</script>
