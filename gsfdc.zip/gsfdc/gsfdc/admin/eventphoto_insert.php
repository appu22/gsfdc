<?php

$event_id=$_POST['event_id'];
$photo=$_POST['photo'];
$photo_name=$_POST['photo_name'];

include('dbconnect.php');
$sql="insert into event_photos values(null,'$event_id','$photo','$photo_name')";
mysql_query($sql);
?>

<script>
alert("values inserted")
document.location='eventphoto_view.php'
</script>