<?php include("meta_tags.php") ?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php")?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2><span class="style1">News</span></h2>
            <div class="table-responsive">
<?php include('val.php');?>
<form name="form1" method="post" action="news_insert.php" id="formID">
  <p align="center" class="style1">&nbsp;</p>
  <div align="center">
              <table class="table table-bordered table-hover tablesorter">
      <tr>
        <td width="97" height="73"><span class="style2">News Title</span></td>
        <td width="242"><input name="n_title" type="text" id="n_title" class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td height="64"><span class="style2">News date</span></td>
        <td><p>
          <input name="n_date" type="text" id="n_date" class="validate[required]">
        </p>
        <p>&nbsp;            </p></td>
      </tr>
      <tr>
        <td><span class="style2">Description</span></td>
        <td><textarea name="descr" id="descr" class="validate[required]"></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
