<?php include("meta_tags.php") ?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php")?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2><span class="style1">Event Photos</span></h2>
            <div class="table-responsive">
			<?php include('val.php');?>
<form name="form1" method="post" action="eventphoto_insert.php" id="formID">
  <div align="center">
              <table class="table table-bordered table-hover tablesorter">
      <tr>
        <td><strong>Event ID </strong></td>
        <td><input name="event_id" type="text" id="event_id" class="validate[required,custom[onlyNumber]]"></td>
      </tr>
      <tr>
        <td><strong>Photo</strong></td>
        <td><input name="photo" type="text" id="photo" class="validate[required]"></td>
      </tr>
      <tr>
        <td><strong>Photo Name </strong></td>
        <td><input name="photo_name" type="text" id="photo_name" class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
