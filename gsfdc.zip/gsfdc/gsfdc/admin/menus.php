<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">SB Admin</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li class="active"><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="event_view.php"><i class="fa fa-bar-chart-o"></i> Event</a></li>
            <li><a href="eventphoto_view.php"><i class="fa fa-table"></i> Event Photos</a></li>
			 <li><a href="gallery_view.php"><i class="fa fa-table"></i>Gallry</a></li>
			  <li><a href="gallerydetails_view.php"><i class="fa fa-table"></i> Gallry Details </a></li>
			   <li><a href="news_view.php"><i class="fa fa-table"></i> news</a></li>
			   			   <li><a href="staff_view.php"><i class="fa fa-table"></i> Staff</a></li>

            <li><a href="../logout.php"><i class="fa fa-edit"></i> logout</a></li>
         

          <ul class="nav navbar-nav navbar-right navbar-user">
             </ul>
        </div><!-- /.navbar-collapse -->
      </nav>