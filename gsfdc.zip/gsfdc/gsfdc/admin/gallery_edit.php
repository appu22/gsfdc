<?php
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql="select * from gallery where gal_id='$id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);

?>

<?php include("meta_tags.php");?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>School Events</h2>
            <div class="table-responsive">
<?php include('val.php'); ?>
<body>

<form name="form1" method="post" action="gallery_update.php" id="formID">
  <p align="center" class="style1">Gallery </p>
  <div align="center">
   <table width="308" height="220" class="table table-bordered table-hover tablesorter">
	<p><input name="gal_id" type="hidden" id="gal_id" value=<?php echo $row['gal_id'];?> ></p>
      <tr>
        <td width="131" height="52"><strong>Gallery Title</strong></td>
        <td width="216"><input name="gal_title" type="text" id="gal_title" value=<?php echo $row['gal_title'];?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td><strong>Gallery Date </strong></td>
        <td><input name="gal" type="text" id="gal" value=<?php echo $row['gal'] ?> class="validate[required]"></td>
      </tr>
      <tr>
        <td height="45">&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p align="center" class="style1">&nbsp; </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
<?php include('footer.php');?>
