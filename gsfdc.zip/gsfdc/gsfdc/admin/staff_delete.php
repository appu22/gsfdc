<?php

$id=$_REQUEST['id'];
include('dbconnect.php');

$sql="delete from staff where staff_id='$id'";
$res=mysql_query($sql);

?>
<script>
alert('Values deleted');
document.location="staff_view.php";
</script>