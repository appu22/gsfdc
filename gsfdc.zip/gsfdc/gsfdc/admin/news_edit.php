<?php
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql="select * from news where news_id='$id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);

?>
<?php include("meta_tags.php");?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>School Events</h2>
            <div class="table-responsive">
<?php include('val.php'); ?>
<form name="form1" method="post" action="news_update.php" id="formID">
  <p align="center" class="style1">News</p>
  <div align="center">
   <table width="308" height="220" class="table table-bordered table-hover tablesorter">
 	<p><input name="news_id" type="hidden" id="news_id" value=<?php echo $row['news_id'];?>></p>
      <tr>
        <td width="97" height="73"><span class="style2">News Title</span></td>
        <td width="242"><input name="n_title" type="text" id="n_title" value=<?php echo $row['n_title']; ?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td height="64"><span class="style2">News date</span></td>
        <td>
          <input name="n_date" type="text" id="n_date" value=<?php echo $row['n_date'];?> class="validate[required]"></td>
      </tr>
      <tr>
        <td><span class="style2">Description</span></td>
        <td><textarea name="descr" id="descr" class="validate[required]"><?php echo $row['descr'];?></textarea></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('footer.php');?>
