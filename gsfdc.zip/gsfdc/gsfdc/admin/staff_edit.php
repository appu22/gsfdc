<?php
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql="select * from staff where staff_id='$id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?>
<?php include("meta_tags.php");?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>School Events</h2>
            <div class="table-responsive">
<?php include('val.php'); ?>
<form name="form1" method="post" action="staff_update.php" id="formID">
  <p align="center" class="style1">Staff Details</p>
  <p align="center" class="style1">&nbsp;</p>
  <div align="center">
    <table width="406" height="340" border="1" bgcolor="#CCCCCC">
	<p><input name="staff_id" type="hidden" id="staff_id" value=<?php echo $row['staff_id'];?>> </p>
      <tr>
        <td><strong>Staff Name</strong></td>
        <td><input name="staff_name" type="text" id="staff_name" value=<?php echo $row['staff_name'];?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td><strong>Qualification</strong></td>
        <td><input name="quali" type="text" id="quali" value=<?php echo $row['quali'];?> class="validate[required]"></td>
      </tr>
      <tr>
        <td><strong>Designation</strong></td>
        <td><input name="designation" type="text" id="designation" value=<?php echo $row['designation']; ?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td><strong>Mobile</strong></td>
        <td><input name="contact" type="text" id="contact" value=<?php echo $row['contact'];?> class="validate[required,custom[onlyNumber]]"></td>
      </tr>
      <tr>
        <td><strong>Email</strong></td>
        <td><input name="email" type="text" id="email" value=<?php echo $row['email'];?> class="validate[required,custom[email]]"></td>
      </tr>
      <tr>
        <td><strong>Joining Year </strong></td>
        <td><input name="j_date" type="text" id="j_date" value=<?php echo $row['j_date'];?> class="validate[required]"></td>
      </tr>
      <tr>
        <td><strong>Photo</strong></td>
        <td><input name="photo" type="text" id="photo" value=<?php echo $row['photo']; ?> class="validate[required]"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input name="Submit" type="submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p align="center" class="style1">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
<?php include('footer.php');?>