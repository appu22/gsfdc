<?php 
include('dbconnect.php');

$gal_id=$_POST['gal_id'];
$photo=$_POST['photo'];
$photo_title=$_POST['photo_title'];

$sql="insert into gallery_details values(null,'$gal_id','$photo','$photo_title')";
mysql_query($sql);
?>
<script>
alert('Values inserted');
document.location="gallerydetails_view.php";
</script>