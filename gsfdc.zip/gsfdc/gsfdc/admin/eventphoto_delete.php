<?php
$id=$_REQUEST['id'];
include('dbconnect.php');

$sql="delete from event_photos where ep_id='$id'";
$res=mysql_query($sql);

?>
<script>
alert('Values Deleted');
document.location="eventphoto_view.php";
</script>