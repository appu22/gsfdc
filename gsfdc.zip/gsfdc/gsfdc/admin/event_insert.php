<?php

$e_title=$_POST['e_title'];
$e_date=$_POST['e_date'];
$descr=$_POST['descr'];
$location=$_POST['location'];

//$con=mysql_connect("localhost","root","","gsfdc");
 include('dbconnect.php');
$sql="insert into events(event_id,e_title,e_date,descr,location) values(null,'$e_title','$e_date','$descr','$location')";

mysql_query($sql);
?>

<script>
alert('value inserted');
document.location="event_view.php";
</script>