<?php include("meta_tags.php") ?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php")?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="staff.php"><i class="fa fa-dashboard"></i> Add New</a></li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>Bordered Table</h2>
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
    <tr>
      <td width="85"><strong>Staff Name</strong></td>
      <td width="92"><strong>Qualification</strong></td>
      <td width="79"><strong>Designation</strong></td>
      <td width="75"><strong>Mobile</strong></td>
      <td width="53"><strong>Email</strong></td>
      <td width="124"><strong>Joining Year</strong></td>
      <td width="80"><strong>Photo</strong></td>
	  <td width="55"><strong>Delete</strong></td>
	  <td width="59"><strong>Edit</strong></td>
    </tr>
	<?php
  
 include('dbconnect.php');
$sql="select * from staff";
  
$res=mysql_query($sql);
while($row=mysql_fetch_array($res))
{
  ?>
  <tr>
    <td><?php echo $row['staff_name'];?></td>
    <td><?php echo $row['quali'];?></td>
    <td><?php echo $row['designation'];?></td>
	<td><?php echo $row['contact'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['j_date'];?></td>
	<td><?php echo $row['photo'];?></td>
	<td><a onClick="return confirm('R u Sure...?')"; href="staff_delete.php?id=<?php echo $row['staff_id'];?>">Delete</a></td>
	<td><a onClick="return confirm('R u Sure...?')"; href="staff_edit.php?id=<?php echo $row['staff_id'];?>">Edit</a></td>
  </tr>
  <?php
  }
  ?>
  </table>
</div>
</body>
</html>
<?php include('footer.php');?>