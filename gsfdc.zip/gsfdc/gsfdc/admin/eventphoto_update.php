<?php
$ep_id=$_REQUEST['ep_id'];
$event_id=$_POST['event_id'];
$photo=$_POST['photo'];
$photo_name=$_POST['photo_name'];

include('dbconnect.php');

 $sql="update event_photos set event_id='$event_id',photo='$photo',photo_name='$photo_name' where ep_id='$ep_id'";
mysql_query($sql);
?>

<script>
alert("values Upadated..")
document.location='eventphoto_view.php'
</script>