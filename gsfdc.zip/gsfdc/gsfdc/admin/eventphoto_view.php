<?php include("meta_tags.php");?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="eventphoto.php"><i class="fa fa-dashboard"></i> Add New</a></li>
            
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>Bordered Table</h2>
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
    <tr>
      <td><strong>Event ID</strong></td>
      <td><strong>Photo</strong></td>
      <td><strong>Photo Name </strong></td>
	  <td><strong>Photo Delete </strong></td>
	  <td><strong>Photo Edit </strong></td>
	  
	 
    </tr>
	<?php
	include('dbconnect.php');
	$sql="select * from event_photos";
	
	$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	{
	?>
    <tr>
      <td><?php echo $row['event_id'];?></td>
      <td><?php echo $row['photo'];?></td>
      <td><?php echo $row['photo_name'];?></td>
	  <td><p><a onClick="return Confirm('r u sure ....?')"; href="eventphoto_delete.php?id=<?php echo $row['ep_id'];?>">Delete</a></p>
	  <td><p><a onClick="return Confirm('r u sure ....?')"; href="eventphoto_edit.php?id=<?php echo $row['ep_id'];?>">Edit</a></p>

      </td>
    </tr>
	<?php
	 }
	?>
  </table>
</div>
</body>
</html>
<?php include('footer.php');?>
