<?php

$id=$_REQUEST['id'];
include('dbconnect.php');

$sql="delete from events where event_id='$id'";
$res=mysql_query($sql);

?>
<script>
alert('Values deleted');
document.location="event_view.php";
</script>