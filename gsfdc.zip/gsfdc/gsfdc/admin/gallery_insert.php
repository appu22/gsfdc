<?php

$gal_title=$_POST['gal_title'];
$gal=$_POST['gal'];

//$cn=mysqli_connect("localhost","root","appu22","gsfdc");

include('dbconnect.php');
$sql="insert into gallery values(null,'$gal_title','$gal')";
mysql_query($sql);

?>
<script>
alert("values inserted")
document.location= "gallery_view.php";
</script>
