<?php include("meta_tags.php") ?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>School Events</h2>
            <div class="table-responsive">
       <?php include ('val.php'); ?>      
<form name="form1" method="post" action="event_insert.php" id="formID">
 
  <div align="center">
   <table width="308" height="220" class="table table-bordered table-hover tablesorter">
      <tr>
        <th>Event Title </th>
        <td><input name="e_title" type="text" id="e_title" class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td><strong>Event Date</strong></td>
        <td><input name="e_date" type="text" id="e_date" class="validate[required,custom[onlyNumber]]"></td>
      </tr>
      <tr>
        <td><strong>Description</strong></td>
        <td><textarea name="descr" id="descr" class="validate[required]"></textarea></td>
      </tr>
      <tr>
        <td><strong>Location</strong></td>
        <td><input name="location" type="text" id="location" class="validate[required]"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
    </table>
  </div>
  <p align="center" class="style1">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('footer.php');?>
