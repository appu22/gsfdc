<?php 
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql="select * from gallery_details where gd_id='$id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);

?>
<?php include("meta_tags.php");?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>School Events</h2>
            <div class="table-responsive">
<?php include('val.php'); ?>
<body>

<form name="form1" method="post" action="gallerydetails_update.php" id="formID">
  <p align="center" class="style1">Gallery Details</p>
  <div align="center">
   <table width="308" height="220" class="table table-bordered table-hover tablesorter">
		<p><input name="gd_id" type="hidden" id="gd_id" value=<?php echo $row['gd_id'];?>></p>
      <tr>
        <td><strong>Gallery ID </strong></td>
        <td><input name="gal_id" type="text" id="gal_id" value=<?php echo $row['gal_id'];?> class="validate[required,custom[onlyNumber]]"></td>
      </tr>
      <tr>
        <td><strong>Photo</strong></td>
        <td><input name="photo" type="text" id="photo" value=<?php echo $row['photo'];?> class="validate[required]"></td>
      </tr>
      <tr>
        <td><strong>Photo Title</strong></td>
        <td><input name="photo_title" type="text" id="photo_title" value=<?php echo $row['photo_title'];?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
      </table>
  </div>
  <p align="center" class="style1">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
</body>
</html>
<?php include('footer.php');?>
