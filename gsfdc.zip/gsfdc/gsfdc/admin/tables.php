<?php include page="meta_tags.php">?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include page="menus.php">?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>Bordered Table</h2>
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
                <thead>
                  <tr>
                    <th>Page <i class="fa fa-sort"></i></th>
                    <th>Visits <i class="fa fa-sort"></i></th>
                    <th>% New Visits <i class="fa fa-sort"></i></th>
                    <th>Revenue <i class="fa fa-sort"></i></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>/index.html</td>
                    <td>1265</td>
                    <td>32.3%</td>
                    <td>$321.33</td>
                  </tr>
                  <tr>
                    <td>/about.html</td>
                    <td>261</td>
                    <td>33.3%</td>
                    <td>$234.12</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="col-lg-6">
            <h2>&nbsp;</h2>
          </div>
        </div><div class="row"><div class="col-lg-6"></div>
		<?php include('footer.php');?>
         <jsp:include page="footer.jsp"></jsp:include>