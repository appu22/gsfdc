<?php
$event_id=$_REQUEST['event_id'];
$e_title=$_POST['e_title'];
$e_date=$_POST['e_date'];
$descr=$_POST['descr'];
$location=$_POST['location'];

//$con=mysql_connect("localhost","root","","gsfdc");
 include('dbconnect.php');
$sql="update events set e_title='$e_title',e_date='$e_date',descr='$descr',location='$location' where event_id='$event_id'";

mysql_query($sql);
?>

<script>
alert('value updated');
document.location="event_view.php";
</script>