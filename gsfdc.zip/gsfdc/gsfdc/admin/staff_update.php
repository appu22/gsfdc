<?php
$staff_id=$_REQUEST['staff_id'];
$staff_name=$_POST['staff_name'];
$quali=$_POST['quali'];
$designation=$_POST['designation'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$j_date=$_POST['j_date']; 
$photo=$_POST['photo'];

//$cn=mysqli_connect("localhost","root","appu22","gsfdc");
include('dbconnect.php');
$sql="update staff set staff_name='$staff_name',quali='$quali',designation='$designation',contact='$contact',email='$email',j_date='$j_date',photo='$photo' where staff_id='$staff_id'";

mysql_query($sql);
?>
<script>
alert('values Updated')
document.location="staff_view.php";
</script>
