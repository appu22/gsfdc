<?php
$gal_id=$_REQUEST['gal_id'];
$gal_title=$_POST['gal_title'];
$gal=$_POST['gal'];

//$cn=mysqli_connect("localhost","root","appu22","gsfdc");

include('dbconnect.php');
$sql="update gallery set gal_title='$gal_title',gal='$gal' where gal_id='$gal_id'";
mysql_query($sql);

?>
<script>
alert("values Upadted")
document.location= "gallery_view.php";
</script>
