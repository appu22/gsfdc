<?php 
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql="delete from gallery where gal_id='$id'";
$res=mysql_query($sql);

?>

<script>
alert('Values deleted...');
document.location="gallery_view.php";
</script>