<?php 
//$cn=mysqli_connect("localhost","root","appu22","gsfdc");
$news_id=$_REQUEST['news_id'];
$n_title=$_POST['n_title'];
$n_date=$_POST['n_date'];
$descr=$_POST['descr'];

include('dbconnect.php');
$sql="update news set n_title='$n_title',n_date='$n_date',descr='$descr' where news_id='$news_id'";
mysql_query($sql);
 // $res=mysql_query($sql);

?>
<script>
alert('values Upadted' )
document.location="news_view.php";
//document.location="stud.php";
</script>