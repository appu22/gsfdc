<?php
include('dbconnect.php');
$id=$_REQUEST['id'];
$sql= "select * from events where event_id='$id'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
?><?php include("meta_tags.php");?>
  <style type="text/css">
<!--
.style1 {font-weight: bold}
-->
  </style>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="index.html"><i class="fa fa-dashboard"></i> Dashboard</a></li>
              <li class="active"><i class="fa fa-table"></i> Tables</li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2><span class="style1">Event Photos</span></h2>
            <div class="table-responsive">
<?php include('val.php'); ?>
<body>
<form name="form1" method="post" action="event_update.php" id="formID">
  <div align="center">
   <table width="308" height="220" class="table table-bordered table-hover tablesorter">
	<p><input name="event_id" type="hidden" id="event_id" value=<?php echo $row['event_id'];?>></p>
      <tr>
        <td><strong>Event Title </strong></td>
        <td><input name="e_title" type="text" id="e_title" value=<?php echo $row['e_title'];?> class="validate[required,custom[onlyLetter]]"></td>
      </tr>
      <tr>
        <td><strong>Event Date</strong></td>
        <td><input name="e_date" type="text" id="e_date" value=<?php echo $row['e_date'];?> ></td>
      </tr>
      <tr>
        <td><strong>Description</strong></td>
        <td><textarea name="descr" id="descr" class="validate[required]"> <?php echo $row['descr'];?></textarea></td>
      </tr>
      <tr>
        <td><strong>Location</strong></td>
        <td><input name="location" type="text" id="location" value=<?php echo $row['location'];?> class="validate[required]"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="Submit" value="Submit"></td>
      </tr>
    </table>
  </div>
  <p align="center" class="style1">&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<?php include('footer.php');?>
