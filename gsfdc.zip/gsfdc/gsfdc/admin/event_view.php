<?php include("meta_tags.php");?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php");?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="event.php"><i class="fa fa-dashboard"></i> Add New</a></li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>Bordered Table</h2>
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
    <tr>
      <td width="163"><strong>Event Title </strong></td>
      <td width="185"><strong>Event Date</strong></td>
      <td width="135"><strong>Description</strong></td>
      <td width="125"><strong>Location</strong></td>
	  <td width="125"><strong>DELETE</strong></td>
	   <td width="125"><strong>Edit</strong></td>
	  

    </tr>
	<?php
	include('dbconnect.php');
	$sql="select * from events";
	
	$res=mysql_query($sql);
	while($row=mysql_fetch_array($res))
	//while($row=mysql_fetch_array($res))
	{
	?>
    <tr>
      <td><?php echo $row['e_title']; ?></td>
      <td><?php echo $row['e_date'];?></td>
      <td><?php echo $row['descr']; ?></td>
      <td><?php echo $row['location'];?></td>
	  <td><a onClick="return Confirm('Are u sure....?');" href="event_delete.php?id=<?php echo $row['event_id']; ?>">Delete</a> </td>
	 <td><a onClick="return Confirm('Are u sure....?');" href="event_edit.php?id=<?php echo $row['event_id']; ?>">Edit</a> </td>
	

    </tr>
	<?php
	  }
	?>
  </table>
</div>

</body>
</html>
<?php include('footer.php');?>