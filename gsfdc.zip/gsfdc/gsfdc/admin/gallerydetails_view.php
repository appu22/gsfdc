<?php include("meta_tags.php") ?>
  <body>

    <div id="wrapper">
      <!-- Sidebar -->
      <?php include("menus.php")?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Tables <small>Sort Your Data</small></h1>
            <ol class="breadcrumb">
              <li><a href="gallerydetails.php"><i class="fa fa-dashboard"></i> Add New</a></li>
            </ol>
            
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-6">
            <h2>Bordered Table</h2>
            <div class="table-responsive">
              <table class="table table-bordered table-hover tablesorter">
    <tr>
      <td>Gallery ID</td>
      <td>Photo</td>
      <td>Photo Title</td>
	  <td>DELETE</td>
	  <td>Edit</td>
    </tr>
    <?php 
  include('dbconnect.php');
  $sql="select * from gallery_details ";
  $res=mysql_query($sql);
  while($row=mysql_fetch_array($res))
  {
  ?>
    <tr>
      <td><?php echo $row['gal_id'];?></td>
      <td><?php echo $row['photo'];?></td>
      <td><?php echo $row['photo_title'];?></td>
	  <td><a onClick="return confirm ('R u  sure ...?')"; href="gallerydetails_delete.php?id=<?php echo $row['gd_id'];?>">delete</a> </td>
	 <td><a onClick="return confirm ('R u  sure ...?')"; href="gallerydetails_edit.php?id=<?php echo $row['gd_id'];?>">Edit</a> </td>

    </tr>
    <?php } ?>
  </table>
</div>
<p>&nbsp; </p>
</body>
</html>
<?php include('footer.php');?>