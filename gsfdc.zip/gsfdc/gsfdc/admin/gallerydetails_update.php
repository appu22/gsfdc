<?php 
include('dbconnect.php');
$gd_id=$_REQUEST['gd_id'];
$gal_id=$_POST['gal_id'];
$photo=$_POST['photo'];
$photo_title=$_POST['photo_title'];

$sql="update gallery_details set gal_id='$gal_id',photo='$photo',photo_title='$photo_title' where gd_id='$gd_id'";
mysql_query($sql);
?>
<script>
alert('Values Updated');
document.location="gallerydetails_view.php";
</script>